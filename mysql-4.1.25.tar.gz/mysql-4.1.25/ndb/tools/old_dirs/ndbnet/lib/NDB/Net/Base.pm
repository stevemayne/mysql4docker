package NDB::Net::Base;

use strict;
use Carp;

require NDB::Util::Base;

use vars qw(@ISA);
@ISA = qw(NDB::Util::Base);

1;
# vim:set sw=4:
